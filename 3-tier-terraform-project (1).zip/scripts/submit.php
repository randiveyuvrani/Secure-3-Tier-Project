<?php
$conn = new mysqli('RDS_ENDPOINT','admin','Jayshreeram','userformdb');
if($conn->connect_error){die("Connection failed");}
$stmt = $conn->prepare("INSERT INTO users (name, email) VALUES (?, ?)");
$stmt->bind_param("ss", $_POST['name'], $_POST['email']);
$stmt->execute();
echo "Registered Successfully";
?>