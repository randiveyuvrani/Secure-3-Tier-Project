#!/bin/bash
apt update -y
apt install apache2 php php-mysql -y
cd /var/www/html
wget https://raw.githubusercontent.com/randiveyuvrani/aws-terraform-projects/main/submit.php
systemctl restart apache2