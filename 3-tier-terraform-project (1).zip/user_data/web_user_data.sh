#!/bin/bash
apt update -y
apt install nginx -y
echo "<html><body><h1>Register</h1><form action='http://<APP_PRIVATE_IP>/submit.php' method='post'>
Name: <input type='text' name='name'><br>
Email: <input type='text' name='email'><br>
<input type='submit'></form></body></html>" > /var/www/html/index.html
systemctl restart nginx